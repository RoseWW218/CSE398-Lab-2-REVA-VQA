#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_ROOT"

MODEL_BASE="$HOME/models/Qwen3-VL-4B-Instruct"
MODEL_PATH="$PROJECT_ROOT/outputs/qwen_reva_1000_ep1/checkpoint-250"
VIDEO_ROOT="/data/datasets/ReVA"
GT_FILE="$PROJECT_ROOT/data/eval/reva_test_200.json"
OUTPUT_DIR="$PROJECT_ROOT/outputs/qwen_sft_1000_ep1_real200_metadata"
GPU_ID="${GPU_ID:-3}"

test -s "$MODEL_PATH/adapter_config.json"
test -s "$MODEL_PATH/adapter_model.safetensors"
test -s "$GT_FILE"

if [ -e "$OUTPUT_DIR" ]; then
    echo "Output directory already exists: $OUTPUT_DIR" >&2
    echo "Stopping to prevent overwriting evaluation results." >&2
    exit 1
fi

mkdir -p "$PROJECT_ROOT/logs" "$OUTPUT_DIR"

export MY_PROMPT_TEMPLATE="This is a video with duration {duration} seconds.
Please carefully watch the video and answer the multiple-choice question below.
Think step-by-step within <think> </think> tags, then provide only the letter of the correct option within <answer> </answer> tags.
Question: {input_text}"

{
    echo "MODEL_PATH=$MODEL_PATH"
    echo "MODEL_BASE=$MODEL_BASE"
    echo "VIDEO_ROOT=$VIDEO_ROOT"
    echo "GT_FILE=$GT_FILE"
    echo "MAX_FRAMES=4"
    echo "MAX_PIXELS=50176"
    echo "BACKEND=transformers"
    echo "DTYPE=float16"
    echo "ATTENTION=sdpa"
    echo "BATCH_SIZE=1"
    echo "SEED=42"
    echo "ADAPTER=$MODEL_PATH"
    echo "VIDEO_METADATA=original_fps_and_frame_indices"
    echo "DO_SAMPLE_FRAMES=False"
    echo "MY_PROMPT_TEMPLATE=$MY_PROMPT_TEMPLATE"
    sha256sum "$GT_FILE"
    sha256sum reva_eval/inference_vllm_origin_number.py
    sha256sum "$MODEL_PATH/adapter_model.safetensors"
} > "$OUTPUT_DIR/run_config.txt"

CUDA_VISIBLE_DEVICES="$GPU_ID" \
python -u reva_eval/inference_vllm_origin_number.py \
    --model-path "$MODEL_PATH" \
    --model-base "$MODEL_BASE" \
    --video_dir "$VIDEO_ROOT" \
    --gt_file "$GT_FILE" \
    --output_dir "$OUTPUT_DIR" \
    --output_name pred \
    --max_frames 4 \
    --max_pixels 50176 \
    --backend transformers \
    --no-cache \
    2>&1 | tee "$PROJECT_ROOT/logs/qwen_sft_1000_ep1_real200_metadata.log"

python scripts/score_reva_predictions.py \
    --output-dir "$OUTPUT_DIR" \
    --gt-file "$GT_FILE" \
    2>&1 | tee "$PROJECT_ROOT/logs/qwen_sft_1000_ep1_real200_metadata_score.log"

echo "Fine-tuned evaluation completed successfully."

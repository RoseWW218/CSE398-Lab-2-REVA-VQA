#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PROJECT_ROOT"

MODEL_PATH="${MODEL_PATH:-$HOME/models/Qwen3-VL-4B-Instruct}"
VIDEO_ROOT="${VIDEO_ROOT:-/data/datasets/ReVA}"
GT_FILE="$PROJECT_ROOT/data/eval/reva_test_200.json"
OUTPUT_DIR="$PROJECT_ROOT/outputs/qwen_base_real200_metadata"
GPU_ID="${GPU_ID:-1}"

mkdir -p "$PROJECT_ROOT/logs" "$OUTPUT_DIR"

if [ -e "$OUTPUT_DIR/pred.json" ]; then
    echo "Existing predictions found: $OUTPUT_DIR/pred.json" >&2
    echo "Stopping to prevent mixing results from different runs." >&2
    exit 1
fi

export MY_PROMPT_TEMPLATE="This is a video with duration {duration} seconds.
Please carefully watch the video and answer the multiple-choice question below.
Think step-by-step within <think> </think> tags, then provide only the letter of the correct option within <answer> </answer> tags.
Question: {input_text}"

{
    echo "MODEL_PATH=$MODEL_PATH"
    echo "VIDEO_ROOT=$VIDEO_ROOT"
    echo "GT_FILE=$GT_FILE"
    echo "MAX_FRAMES=4"
    echo "MAX_PIXELS=50176"
    echo "BACKEND=transformers"
    echo "DTYPE=float16"
    echo "ATTENTION=sdpa"
    echo "BATCH_SIZE=1"
    echo "SEED=42"
    echo "ADAPTER=none"
    echo "VIDEO_METADATA=original_fps_and_frame_indices"
    echo "DO_SAMPLE_FRAMES=False"
    echo "MY_PROMPT_TEMPLATE=$MY_PROMPT_TEMPLATE"
    sha256sum "$GT_FILE"
    sha256sum reva_eval/inference_vllm_origin_number.py
} > "$OUTPUT_DIR/run_config.txt"

CUDA_VISIBLE_DEVICES="$GPU_ID" \
python -u reva_eval/inference_vllm_origin_number.py \
    --model-path "$MODEL_PATH" \
    --video_dir "$VIDEO_ROOT" \
    --gt_file "$GT_FILE" \
    --output_dir "$OUTPUT_DIR" \
    --output_name pred \
    --max_frames 4 \
    --max_pixels 50176 \
    --backend transformers \
    --no-cache \
    2>&1 | tee "$PROJECT_ROOT/logs/qwen_base_real200_metadata.log"

python scripts/score_reva_predictions.py \
    --output-dir "$OUTPUT_DIR" \
    --gt-file "$GT_FILE" \
    2>&1 | tee "$PROJECT_ROOT/logs/qwen_base_real200_metadata_score.log"

#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_ROOT"

export CUDA_VISIBLE_DEVICES=3
export USE_DEEPSPEED=0
export NPROC_PER_NODE=1
export MODEL_PATH="$HOME/models/Qwen3-VL-4B-Instruct"
export DATASETS=reva_train_small
export OUTPUT_DIR="$PROJECT_ROOT/outputs/qwen_reva_1000_ep1_lr1e4"
export RUN_NAME=qwen_reva_1000_ep1_lr1e4
export EPOCHS=1
export LR=1e-4
export BATCH_SIZE=1
export GRAD_ACCUM_STEPS=4
export SAVE_STEPS=50
export MODEL_MAX_LENGTH=2048
export DATALOADER_NUM_WORKERS=0
export MAX_PIXELS=50176
export VIDEO_MAX_FRAMES=4
export VIDEO_MIN_FRAMES=2
export VIDEO_MAX_PIXELS=50176
export VIDEO_MIN_PIXELS=784
export VIDEO_FPS=1
export LORA_R=8
export LORA_ALPHA=16
export LORA_DROPOUT=0.05
export REPORT_TO=none

if [ -d "$OUTPUT_DIR" ]; then
    echo "ERROR: training output directory already exists." >&2
    exit 1
fi

python - <<'PY'
import json
from pathlib import Path

path = Path("data/qwen_train/train.json")
data = json.loads(path.read_text(encoding="utf-8"))
assert len(data) == 1000, "Expected exactly 1000 training samples."
print("Verified training samples:", len(data))
PY

mkdir -p "$OUTPUT_DIR"
env | sort | grep -E \
'^(CUDA_VISIBLE_DEVICES|USE_DEEPSPEED|NPROC_PER_NODE|MODEL_PATH|DATASETS|OUTPUT_DIR|RUN_NAME|EPOCHS|LR|BATCH_SIZE|GRAD_ACCUM_STEPS|SAVE_STEPS|MODEL_MAX_LENGTH|DATALOADER_NUM_WORKERS|MAX_PIXELS|VIDEO_|LORA_|REPORT_TO)=' \
    > "$OUTPUT_DIR/run_config.txt"
sha256sum data/qwen_train/train.json \
    qwen_finetune/qwenvl/train/train_qwen.py \
    qwen_finetune/scripts/sft_7b.sh \
    > "$OUTPUT_DIR/input_checksums.txt"

bash scripts/run_finetune_qwen.sh
echo "Training completed successfully."

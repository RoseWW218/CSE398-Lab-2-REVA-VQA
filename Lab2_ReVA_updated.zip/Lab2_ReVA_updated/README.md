# Lab 2: ReVA VQA — Updated Experiments

This submission contains the implemented data preparation, Qwen training and evaluation, VILA evaluation, seven unit tests, and four formal evaluation results.

## Results

| Model | Learning rate | Epochs | Correct / Total | Accuracy |
|---|---|---|---|---|
| Qwen3-VL-4B baseline | — | — | 137/200 | 68.5% |
| Qwen LoRA | 2e-5 | 1 | 144/200 | 72.0% |
| Qwen LoRA | 1e-4 | 1 | 145/200 | 72.5% |
| VILA1.5-3B baseline | — | — | 101/200 | 50.5% |

All four result sets match the same 200 test question IDs. Both LoRA runs use 1,000 training QA pairs, rank 8, alpha 16, q/k/v/o projections, batch size 1, gradient accumulation 4, and 250 optimizer update steps.

## Files

- `data/qwen_train/train.json`: 1,000 training QA pairs.
- `data/eval/reva_test_200.json`: fixed 200 test QA pairs.
- `data/eval/reva_test_200_vila.json`: corresponding VILA input.
- `outputs/model_comparison.csv`: updated four-experiment summary.
- `outputs/qwen_base_real200_metadata/`: Qwen baseline predictions and scores.
- `outputs/qwen_sft_1000_ep1_real200_metadata/`: LoRA 2e-5 predictions and scores.
- `outputs/qwen_sft_1000_ep1_lr1e4_real200_metadata/`: LoRA 1e-4 predictions and scores.
- `outputs/vila_base_real200/`: VILA predictions and metrics.
- `outputs/qwen_reva_1000_ep1*/`: adapter configuration and training records; model weights are not included.
- `logs/`: selected training and formal evaluation logs.
- `tests/`: seven provided implementation tests.

## Experiment launchers

- Qwen baseline: `scripts/run_baseline_magic_metadata.sh`
- LoRA 2e-5 training: `scripts/run_train_magic_1000.sh`
- LoRA 1e-4 training: `scripts/run_train_magic_1000_lr1e4.sh`
- LoRA 2e-5 evaluation: `scripts/run_eval_magic_1000_ep1.sh`
- LoRA 1e-4 evaluation: `scripts/run_eval_magic_1000_ep1_lr1e4.sh`
- VILA evaluator: `vila_eval/reva_v2.py`

The launchers retain the original Magic paths. Change model paths, dataset root and GPU selection for another machine. Videos, base-model weights, LoRA weights, and external VILA dependencies are not included. Existing output-directory guards prevent overwriting results; use a new output directory when rerunning.

Qwen used FP16, SDPA, four evaluation frames and original video metadata. VILA used four uniformly sampled frames with `fps=0.0`. Prompting and processing differ between model families; Qwen baseline and fine-tuned evaluations use consistent settings.

## Tests

Run `python -m pytest -q` from the project root in an environment with the required dependencies. Test definitions are retained; this packaging step does not constitute a new GPU training run or unit-test execution.

Old smoke-test result tables, failed runs, duplicate backups, 3-epoch outputs and tokenizer copies are excluded. General-purpose helper scripts and upstream training source are retained as code dependencies. `scripts/compare_models.sh` is the original three-model comparison helper; the authoritative four-experiment summary is `outputs/model_comparison.csv`.
